# CSVTimeSeriesAnalysis
class CSVTimeSeriesAnalysis:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def moving_average(self, column_name, window_size):
        index = self.header.index(column_name)
        values = [float(row[index]) for row in self.data]
        return [sum(values[i:i+window_size]) / window_size for i in range(len(values) - window_size + 1)]

    def exponential_smoothing(self, column_name, alpha):
        index = self.header.index(column_name)
        values = [float(row[index]) for row in self.data]
        smoothed = [values[0]]
        for t in range(1, len(values)):
            smoothed.append(alpha * values[t] + (1 - alpha) * smoothed[-1])
        return smoothed
