import random

def random_sample(self, sample_size):
    return random.sample(self.data, sample_size)

def systematic_sample(self, interval):
    return self.data[::interval]
