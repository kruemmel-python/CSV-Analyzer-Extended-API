import random
import numpy as np
from collections import defaultdict, Counter
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import csv

class CSVSampling:
    def __init__(self, data, header):
        self.data = data
        self.header = header
        self._validate_data()

    def _validate_data(self):
        if not self.data:
            raise ValueError("Data cannot be empty.")
        if not isinstance(self.data, list) or not all(isinstance(row, list) for row in self.data):
            raise ValueError("Data must be a list of lists.")
        if not isinstance(self.header, list) or not all(isinstance(col, str) for col in self.header):
            raise ValueError("Header must be a list of strings.")
        if len(self.header) != len(self.data[0]):
            raise ValueError("Header and data rows must have the same length.")

    def random_sample(self, sample_size):
        """
        Zieht eine zufällige Stichprobe aus den Daten.

        :param sample_size: Die Größe der Stichprobe.
        :return: Eine Liste mit der zufälligen Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")
        return random.sample(self.data, sample_size)

    def systematic_sample(self, interval):
        """
        Zieht eine systematische Stichprobe aus den Daten.

        :param interval: Das Intervall für die systematische Stichprobe.
        :return: Eine Liste mit der systematischen Stichprobe.
        """
        if interval <= 0:
            raise ValueError("Interval must be greater than zero.")
        return self.data[::interval]

    def stratified_sample(self, sample_size, stratify_column):
        """
        Zieht eine stratifizierte Stichprobe aus den Daten basierend auf einer bestimmten Spalte.

        :param sample_size: Die Größe der Stichprobe.
        :param stratify_column: Der Name der Spalte, nach der stratifiziert werden soll.
        :return: Eine Liste mit der stratifizierten Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(stratify_column)
        stratified_data = defaultdict(list)

        for row in self.data:
            stratified_data[row[col_index]].append(row)

        sample = []
        for key in stratified_data:
            stratum_size = int(len(stratified_data[key]) / len(self.data) * sample_size)
            if stratum_size > len(stratified_data[key]):
                raise ValueError(f"Not enough data in stratum '{key}' for the requested sample size.")
            sample.extend(random.sample(stratified_data[key], stratum_size))

        return sample

    def weighted_sample(self, sample_size, weights):
        """
        Zieht eine gewichtete Stichprobe aus den Daten.

        :param sample_size: Die Größe der Stichprobe.
        :param weights: Eine Liste mit Gewichten für jede Zeile.
        :return: Eine Liste mit der gewichteten Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")
        if len(weights) != len(self.data):
            raise ValueError("Weights must have the same length as the data.")

        weighted_data = random.choices(self.data, weights=weights, k=sample_size)
        return weighted_data

    def reservoir_sample(self, sample_size):
        """
        Zieht eine Reservoir-Stichprobe aus den Daten.

        :param sample_size: Die Größe der Stichprobe.
        :return: Eine Liste mit der Reservoir-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        reservoir = []
        for i, row in enumerate(self.data):
            if i < sample_size:
                reservoir.append(row)
            else:
                j = random.randint(0, i)
                if j < sample_size:
                    reservoir[j] = row
        return reservoir

    def oversample(self, sample_size, target_column, target_value):
        """
        Oversampling für unbalancierte Daten.

        :param sample_size: Die Größe der Stichprobe.
        :param target_column: Der Name der Spalte, die oversampled werden soll.
        :param target_value: Der Wert, der oversampled werden soll.
        :return: Eine Liste mit der oversampled Stichprobe.
        """
        col_index = self.header.index(target_column)
        target_data = [row for row in self.data if row[col_index] == target_value]
        non_target_data = [row for row in self.data if row[col_index] != target_value]

        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        oversampled_data = random.choices(target_data, k=sample_size - len(non_target_data)) + non_target_data
        return oversampled_data

    def undersample(self, sample_size, target_column, target_value):
        """
        Undersampling für unbalancierte Daten.

        :param sample_size: Die Größe der Stichprobe.
        :param target_column: Der Name der Spalte, die undersampled werden soll.
        :param target_value: Der Wert, der undersampled werden soll.
        :return: Eine Liste mit der undersampled Stichprobe.
        """
        col_index = self.header.index(target_column)
        target_data = [row for row in self.data if row[col_index] == target_value]
        non_target_data = [row for row in self.data if row[col_index] != target_value]

        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        undersampled_data = random.sample(non_target_data, sample_size - len(target_data)) + target_data
        return undersampled_data

    def multistage_sample(self, sample_size, primary_column, secondary_column):
        """
        Mehrstufiges Sampling.

        :param sample_size: Die Größe der Stichprobe.
        :param primary_column: Der Name der primären Spalte für die erste Stufe.
        :param secondary_column: Der Name der sekundären Spalte für die zweite Stufe.
        :return: Eine Liste mit der mehrstufigen Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        primary_col_index = self.header.index(primary_column)
        secondary_col_index = self.header.index(secondary_column)

        primary_sample = self.stratified_sample(sample_size, primary_column)
        secondary_sample = self.stratified_sample(sample_size, secondary_column)

        return primary_sample + secondary_sample

    def bootstrap_sample(self, sample_size):
        """
        Zieht eine Bootstrap-Stichprobe aus den Daten.

        :param sample_size: Die Größe der Stichprobe.
        :return: Eine Liste mit der Bootstrap-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        bootstrap_data = random.choices(self.data, k=sample_size)
        return bootstrap_data

    def adaptive_sample(self, sample_size, target_column, target_value):
        """
        Adaptives Sampling basierend auf der Verteilung der Daten.

        :param sample_size: Die Größe der Stichprobe.
        :param target_column: Der Name der Spalte, die adaptiv gesampled werden soll.
        :param target_value: Der Wert, der adaptiv gesampled werden soll.
        :return: Eine Liste mit der adaptiven Stichprobe.
        """
        col_index = self.header.index(target_column)
        target_data = [row for row in self.data if row[col_index] == target_value]
        non_target_data = [row for row in self.data if row[col_index] != target_value]

        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        target_ratio = len(target_data) / len(self.data)
        non_target_ratio = 1 - target_ratio

        target_sample_size = int(sample_size * target_ratio)
        non_target_sample_size = sample_size - target_sample_size

        adaptive_sample = random.sample(target_data, target_sample_size) + random.sample(non_target_data, non_target_sample_size)
        return adaptive_sample

    def cluster_sample(self, sample_size, cluster_column):
        """
        Cluster Sampling basierend auf einer bestimmten Spalte.

        :param sample_size: Die Größe der Stichprobe.
        :param cluster_column: Der Name der Spalte, nach der geclustert werden soll.
        :return: Eine Liste mit der Cluster-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(cluster_column)
        clusters = defaultdict(list)

        for row in self.data:
            clusters[row[col_index]].append(row)

        cluster_sample = []
        for key in clusters:
            cluster_sample.extend(random.sample(clusters[key], min(sample_size, len(clusters[key]))))

        return cluster_sample

    def balanced_sample(self, sample_size, balance_column):
        """
        Balanced Sampling, bei dem alle Kategorien gleichmäßig vertreten sind.

        :param sample_size: Die Größe der Stichprobe.
        :param balance_column: Der Name der Spalte, nach der balanciert werden soll.
        :return: Eine Liste mit der balancierten Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(balance_column)
        categories = defaultdict(list)

        for row in self.data:
            categories[row[col_index]].append(row)

        category_count = len(categories)
        samples_per_category = sample_size // category_count

        balanced_sample = []
        for key in categories:
            balanced_sample.extend(random.sample(categories[key], min(samples_per_category, len(categories[key]))))

        return balanced_sample

    def progressive_sample(self, initial_sample_size, increment, max_sample_size):
        """
        Progressives Sampling, bei dem die Stichprobe in mehreren Durchgängen größer wird.

        :param initial_sample_size: Die anfängliche Größe der Stichprobe.
        :param increment: Das Inkrement für jeden Durchgang.
        :param max_sample_size: Die maximale Größe der Stichprobe.
        :return: Eine Liste mit der progressiven Stichprobe.
        """
        if initial_sample_size > len(self.data):
            raise ValueError("Initial sample size cannot be greater than the number of data rows.")
        if max_sample_size > len(self.data):
            raise ValueError("Max sample size cannot be greater than the number of data rows.")

        progressive_sample = []
        current_sample_size = initial_sample_size

        while current_sample_size <= max_sample_size:
            progressive_sample.extend(random.sample(self.data, current_sample_size))
            current_sample_size += increment

        return progressive_sample

    def sequential_sample(self, sample_size):
        """
        Zieht eine sequentielle Stichprobe aus den Daten.

        :param sample_size: Die Größe der Stichprobe.
        :return: Eine Liste mit der sequentiellen Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")
        return self.data[:sample_size]

    def quota_sample(self, sample_size, quota_column, quotas):
        """
        Zieht eine Stichprobe basierend auf vordefinierten Quoten für bestimmte Untergruppen.

        :param sample_size: Die Größe der Stichprobe.
        :param quota_column: Der Name der Spalte, nach der die Quoten definiert werden.
        :param quotas: Ein Dictionary mit den Quoten für jede Untergruppe.
        :return: Eine Liste mit der Quoten-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(quota_column)
        quota_data = defaultdict(list)

        for row in self.data:
            quota_data[row[col_index]].append(row)

        quota_sample = []
        for key, quota in quotas.items():
            if quota > len(quota_data[key]):
                raise ValueError(f"Not enough data in quota '{key}' for the requested sample size. Available: {len(quota_data[key])}, Requested: {quota}")
            quota_sample.extend(random.sample(quota_data[key], quota))

        return quota_sample

    def multivariate_adaptive_sample(self, sample_size, target_columns, target_values):
        """
        Multivariates adaptives Sampling basierend auf mehreren Spalten.

        :param sample_size: Die Größe der Stichprobe.
        :param target_columns: Eine Liste der Spaltennamen, die adaptiv gesampled werden sollen.
        :param target_values: Eine Liste der Werte, die adaptiv gesampled werden sollen.
        :return: Eine Liste mit der multivariaten adaptiven Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        if len(target_columns) != len(target_values):
            raise ValueError("Target columns and target values must have the same length.")

        target_data = []
        for row in self.data:
            if all(row[self.header.index(col)] == val for col, val in zip(target_columns, target_values)):
                target_data.append(row)

        non_target_data = [row for row in self.data if row not in target_data]

        target_ratio = len(target_data) / len(self.data)
        non_target_ratio = 1 - target_ratio

        target_sample_size = int(sample_size * target_ratio)
        non_target_sample_size = sample_size - target_sample_size

        adaptive_sample = random.sample(target_data, target_sample_size) + random.sample(non_target_data, non_target_sample_size)
        return adaptive_sample

    def rejection_sample(self, sample_size, target_column, target_distribution):
        """
        Zieht eine Stichprobe basierend auf der Ablehnung von Datenpunkten, die nicht in eine Zielverteilung passen.

        :param sample_size: Die Größe der Stichprobe.
        :param target_column: Der Name der Spalte, nach der die Zielverteilung definiert wird.
        :param target_distribution: Ein Dictionary mit der Zielverteilung für jede Untergruppe.
        :return: Eine Liste mit der Rejection-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(target_column)
        rejection_sample = []

        for row in self.data:
            if row[col_index] in target_distribution and len(rejection_sample) < sample_size:
                if random.random() < target_distribution[row[col_index]]:
                    rejection_sample.append(row)

        return rejection_sample

    def proportional_sample(self, sample_size, proportion_column):
        """
        Zieht eine Stichprobe proportional zur Größe von Untergruppen oder Kategorien.

        :param sample_size: Die Größe der Stichprobe.
        :param proportion_column: Der Name der Spalte, nach der die Proportionen definiert werden.
        :return: Eine Liste mit der proportionalen Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(proportion_column)
        proportions = defaultdict(list)

        for row in self.data:
            proportions[row[col_index]].append(row)

        proportional_sample = []
        for key in proportions:
            proportion_size = int(len(proportions[key]) / len(self.data) * sample_size)
            proportional_sample.extend(random.sample(proportions[key], proportion_size))

        return proportional_sample

    def threshold_sample(self, threshold_column, threshold_value):
        """
        Zieht eine Stichprobe basierend auf einem Schwellenwert.

        :param threshold_column: Der Name der Spalte, nach der der Schwellenwert definiert wird.
        :param threshold_value: Der Schwellenwert.
        :return: Eine Liste mit der Schwellenwert-Stichprobe.
        """
        col_index = self.header.index(threshold_column)
        threshold_sample = [row for row in self.data if float(row[col_index]) > threshold_value]
        return threshold_sample

    def time_based_sample(self, time_column, start_time, end_time):
        """
        Zieht eine Stichprobe basierend auf Zeitintervallen.

        :param time_column: Der Name der Spalte, nach der die Zeitintervalle definiert werden.
        :param start_time: Der Startzeitpunkt.
        :param end_time: Der Endzeitpunkt.
        :return: Eine Liste mit der zeitbasierten Stichprobe.
        """
        col_index = self.header.index(time_column)
        time_sample = [row for row in self.data if start_time <= row[col_index] <= end_time]
        return time_sample

    def dynamic_sample(self, initial_sample_size, increment, max_sample_size, criteria_function):
        """
        Zieht eine dynamische Stichprobe, bei der die Stichprobengröße während der Verarbeitung angepasst wird.

        :param initial_sample_size: Die anfängliche Größe der Stichprobe.
        :param increment: Das Inkrement für jeden Durchgang.
        :param max_sample_size: Die maximale Größe der Stichprobe.
        :param criteria_function: Eine Funktion, die bestimmt, ob die Stichprobe erweitert werden soll.
        :return: Eine Liste mit der dynamischen Stichprobe.
        """
        if initial_sample_size > len(self.data):
            raise ValueError("Initial sample size cannot be greater than the number of data rows.")
        if max_sample_size > len(self.data):
            raise ValueError("Max sample size cannot be greater than the number of data rows.")

        dynamic_sample = []
        current_sample_size = initial_sample_size

        while current_sample_size <= max_sample_size:
            dynamic_sample.extend(random.sample(self.data, current_sample_size))
            if not criteria_function(dynamic_sample):
                break
            current_sample_size += increment

        return dynamic_sample

    def latin_hypercube_sample(self, sample_size, columns):
        """
        Zieht eine Stichprobe basierend auf Latin Hypercube Sampling.

        :param sample_size: Die Größe der Stichprobe.
        :param columns: Eine Liste der Spaltennamen, die gesampled werden sollen.
        :return: Eine Liste mit der Latin Hypercube-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_indices = [self.header.index(col) for col in columns]
        data_array = np.array(self.data)
        lhs_sample = np.zeros((sample_size, len(columns)))

        for i in range(len(columns)):
            col_data = data_array[:, col_indices[i]].astype(float)
            sorted_data = np.sort(col_data)
            intervals = np.linspace(0, len(sorted_data) - 1, sample_size + 1).astype(int)
            lhs_sample[:, i] = sorted_data[intervals[:-1] + np.random.randint(0, intervals[1:] - intervals[:-1], size=sample_size)]

        return lhs_sample.tolist()

    def pareto_sample(self, sample_size, target_column, pareto_ratio=0.8):
        """
        Zieht eine Stichprobe basierend auf der Pareto-Verteilung (z. B. 80/20-Regel).

        :param sample_size: Die Größe der Stichprobe.
        :param target_column: Der Name der Spalte, nach der die Pareto-Verteilung definiert wird.
        :param pareto_ratio: Das Pareto-Verhältnis (standardmäßig 0.8).
        :return: Eine Liste mit der Pareto-Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        col_index = self.header.index(target_column)
        sorted_data = sorted(self.data, key=lambda x: float(x[col_index]), reverse=True)
        pareto_index = int(len(sorted_data) * pareto_ratio)
        pareto_sample = sorted_data[:pareto_index]

        return random.sample(pareto_sample, min(sample_size, len(pareto_sample)))

    def augmented_sample(self, sample_size, augmentation_function):
        """
        Erzeugt augmentierte Daten basierend auf einer Augmentierungsfunktion.

        :param sample_size: Die Größe der Stichprobe.
        :param augmentation_function: Eine Funktion, die die Daten augmentiert.
        :return: Eine Liste mit den augmentierten Daten.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        augmented_data = []
        for row in random.sample(self.data, sample_size):
            augmented_data.append(augmentation_function(row))

        return augmented_data

    def parallel_sample(self, sample_size, sampling_function, num_workers=4):
        """
        Zieht eine Stichprobe unter Verwendung paralleler Verarbeitung.

        :param sample_size: Die Größe der Stichprobe.
        :param sampling_function: Die Sampling-Funktion, die parallel ausgeführt werden soll.
        :param num_workers: Die Anzahl der parallelen Worker.
        :return: Eine Liste mit der parallelen Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        chunk_size = sample_size // num_workers
        chunks = [self.data[i:i + chunk_size] for i in range(0, len(self.data), chunk_size)]

        # Verteilen der übrig gebliebenen Zeilen auf die übrigen Worker
        remaining_rows = self.data[chunk_size * num_workers:]
        for i in range(len(remaining_rows)):
            chunks[i % num_workers].append(remaining_rows[i])

        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            results = list(executor.map(sampling_function, chunks))

        return [item for sublist in results for item in sublist]

    def weighted_parallel_sample(self, sample_size, weights, sampling_function, num_workers=4):
        """
        Zieht eine gewichtete Stichprobe unter Verwendung paralleler Verarbeitung.

        :param sample_size: Die Größe der Stichprobe.
        :param weights: Eine Liste mit Gewichten für jede Zeile.
        :param sampling_function: Die Sampling-Funktion, die parallel ausgeführt werden soll.
        :param num_workers: Die Anzahl der parallelen Worker.
        :return: Eine Liste mit der parallelen gewichteten Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")
        if len(weights) != len(self.data):
            raise ValueError("Weights must have the same length as the data.")

        chunk_size = sample_size // num_workers
        chunks = [self.data[i:i + chunk_size] for i in range(0, len(self.data), chunk_size)]
        weight_chunks = [weights[i:i + chunk_size] for i in range(0, len(weights), chunk_size)]

        # Verteilen der übrig gebliebenen Zeilen auf die übrigen Worker
        remaining_rows = self.data[chunk_size * num_workers:]
        remaining_weights = weights[chunk_size * num_workers:]
        for i in range(len(remaining_rows)):
            chunks[i % num_workers].append(remaining_rows[i])
            weight_chunks[i % num_workers].append(remaining_weights[i])

        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            results = list(executor.map(lambda x: sampling_function(x[0], x[1]), zip(chunks, weight_chunks)))

        return [item for sublist in results for item in sublist]

    def progress_sample(self, sample_size):
        """
        Zieht eine Stichprobe mit Fortschrittsanzeige.

        :param sample_size: Die Größe der Stichprobe.
        :return: Eine Liste mit der Stichprobe.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        sample = []
        for _ in tqdm(range(sample_size), desc="Sampling Progress"):
            sample.append(random.choice(self.data))

        return sample

    def multi_criterion_sample(self, sample_size, criteria_functions):
        """
        Zieht eine Stichprobe basierend auf mehreren Kriterien.

        :param sample_size: Die Größe der Stichprobe.
        :param criteria_functions: Eine Liste von Kriterienfunktionen.
        :return: Eine Liste mit der Stichprobe basierend auf mehreren Kriterien.
        """
        if sample_size > len(self.data):
            raise ValueError("Sample size cannot be greater than the number of data rows.")

        filtered_data = self.data
        for criterion in criteria_functions:
            filtered_data = [row for row in filtered_data if criterion(row)]

        return random.sample(filtered_data, min(sample_size, len(filtered_data)))

    def load_csv(self, file_path):
        """
        Lädt Daten aus einer CSV-Datei.

        :param file_path: Der Pfad zur CSV-Datei.
        """
        with open(file_path, mode='r', newline='') as file:
            reader = csv.reader(file)
            self.header = next(reader)
            self.data = [row for row in reader]
        self._validate_data()

# Beispielverwendung
if __name__ == "__main__":
    # Beispielhafte Daten mit einer numerischen und nicht-numerischen Spalte
    data = [
        ['Alice', '25', 'Engineer'],
        ['Bob', '30', 'Designer'],
        ['Charlie', '35', 'Manager'],
        ['David', '', 'Analyst'],
        ['Eve', '40', '']
    ]
    header = ['Name', 'Age', 'Occupation']

    sampler = CSVSampling(data, header)

    # Zufällige Stichprobe
    random_sample = sampler.random_sample(3)
    print("Random Sample:", random_sample)

    # Systematische Stichprobe
    systematic_sample = sampler.systematic_sample(2)
    print("Systematic Sample:", systematic_sample)

    # Stratifizierte Stichprobe
    stratified_sample = sampler.stratified_sample(3, 'Occupation')
    print("Stratified Sample:", stratified_sample)

    # Gewichtete Stichprobe
    weights = [0.1, 0.2, 0.3, 0.2, 0.2]
    weighted_sample = sampler.weighted_sample(3, weights)
    print("Weighted Sample:", weighted_sample)

    # Reservoir Sampling
    reservoir_sample = sampler.reservoir_sample(3)
    print("Reservoir Sample:", reservoir_sample)

    # Oversampling
    oversampled_data = sampler.oversample(5, 'Occupation', 'Engineer')
    print("Oversampled Data:", oversampled_data)

    # Undersampling
    undersampled_data = sampler.undersample(3, 'Occupation', 'Engineer')
    print("Undersampled Data:", undersampled_data)

    # Mehrstufiges Sampling
    multistage_sample = sampler.multistage_sample(3, 'Occupation', 'Age')
    print("Multistage Sample:", multistage_sample)

    # Bootstrap Sampling
    bootstrap_sample = sampler.bootstrap_sample(3)
    print("Bootstrap Sample:", bootstrap_sample)

    # Adaptives Sampling
    adaptive_sample = sampler.adaptive_sample(3, 'Occupation', 'Engineer')
    print("Adaptive Sample:", adaptive_sample)

    # Cluster Sampling
    cluster_sample = sampler.cluster_sample(3, 'Occupation')
    print("Cluster Sample:", cluster_sample)

    # Balanced Sampling
    balanced_sample = sampler.balanced_sample(3, 'Occupation')
    print("Balanced Sample:", balanced_sample)

    # Progressive Sampling
    progressive_sample = sampler.progressive_sample(1, 1, 3)
    print("Progressive Sample:", progressive_sample)

    # Sequential Sampling
    sequential_sample = sampler.sequential_sample(3)
    print("Sequential Sample:", sequential_sample)

    # Quota Sampling
    quotas = {'Engineer': 2, 'Designer': 1}
    quota_sample = sampler.quota_sample(3, 'Occupation', quotas)
    print("Quota Sample:", quota_sample)

    # Multivariate Adaptive Sampling
    multivariate_sample = sampler.multivariate_adaptive_sample(3, ['Occupation', 'Age'], ['Engineer', '30'])
    print("Multivariate Adaptive Sample:", multivariate_sample)

    # Rejection Sampling
    target_distribution = {'Engineer': 0.5, 'Designer': 0.5}
    rejection_sample = sampler.rejection_sample(3, 'Occupation', target_distribution)
    print("Rejection Sample:", rejection_sample)

    # Proportional Sampling
    proportional_sample = sampler.proportional_sample(3, 'Occupation')
    print("Proportional Sample:", proportional_sample)

    # Threshold Sampling
    threshold_sample = sampler.threshold_sample('Age', 30)
    print("Threshold Sample:", threshold_sample)

    # Time-Based Sampling
    time_sample = sampler.time_based_sample('Age', 25, 35)
    print("Time-Based Sample:", time_sample)

    # Dynamic Sampling
    def criteria_function(sample):
        return len(sample) < 5
    dynamic_sample = sampler.dynamic_sample(1, 1, 5, criteria_function)
    print("Dynamic Sample:", dynamic_sample)

    # Latin Hypercube Sampling
    latin_hypercube_sample = sampler.latin_hypercube_sample(3, ['Age', 'Occupation'])
    print("Latin Hypercube Sample:", latin_hypercube_sample)

    # Pareto Sampling
    pareto_sample = sampler.pareto_sample(3, 'Age')
    print("Pareto Sample:", pareto_sample)

    # Augmented Sampling
    def augmentation_function(row):
        return [str(int(x) + 1) if x.isdigit() else x for x in row]
    augmented_sample = sampler.augmented_sample(3, augmentation_function)
    print("Augmented Sample:", augmented_sample)

    # Parallel Sampling
    def sampling_function(chunk):
        return random.sample(chunk, min(3, len(chunk)))
    parallel_sample = sampler.parallel_sample(3, sampling_function)
    print("Parallel Sample:", parallel_sample)

    # Weighted Parallel Sampling
    def weighted_sampling_function(chunk, weights):
        return random.choices(chunk, weights=weights, k=min(3, len(chunk)))
    weighted_parallel_sample = sampler.weighted_parallel_sample(3, weights, weighted_sampling_function)
    print("Weighted Parallel Sample:", weighted_parallel_sample)

    # Progress Sample
    progress_sample = sampler.progress_sample(3)
    print("Progress Sample:", progress_sample)

    # Multi-Criterion Sampling
    def criterion_1(row):
        return row[1] != ''
    def criterion_2(row):
        return row[2] != ''
    multi_criterion_sample = sampler.multi_criterion_sample(3, [criterion_1, criterion_2])
    print("Multi-Criterion Sample:", multi_criterion_sample)

    # Laden von Daten aus einer CSV-Datei
    sampler.load_csv('example.csv')
    print("Data loaded from CSV:", sampler.data)
