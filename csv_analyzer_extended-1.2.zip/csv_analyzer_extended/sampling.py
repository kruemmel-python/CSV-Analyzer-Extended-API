import random

class CSVSampling:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def random_sample(self, sample_size):
        return random.sample(self.data, sample_size)

    def systematic_sample(self, interval):
        return self.data[::interval]
