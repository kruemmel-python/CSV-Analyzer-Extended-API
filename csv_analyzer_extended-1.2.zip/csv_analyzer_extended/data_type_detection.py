from datetime import datetime

class CSVDataTypeDetection:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def detect_column_types(self):
        column_types = {}
        for i, col_name in enumerate(self.header):
            col_data = [row[i] for row in self.data]
            try:
                float(col_data[0])
                column_types[col_name] = 'Numeric'
            except ValueError:
                try:
                    datetime.strptime(col_data[0], '%Y-%m-%d')
                    column_types[col_name] = 'Date'
                except ValueError:
                    column_types[col_name] = 'Text'
        return column_types
