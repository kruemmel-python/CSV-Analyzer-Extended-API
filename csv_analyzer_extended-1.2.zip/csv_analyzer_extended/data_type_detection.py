from datetime import datetime
import re

class CSVDataTypeDetection:
    def __init__(self, data, header):
        """
        Initialisiert die CSVDataTypeDetection-Klasse.

        :param data: Eine Liste von Listen, die die CSV-Daten enthält.
        :param header: Eine Liste von Strings, die die Spaltennamen enthält.
        """
        self.data = data
        self.header = header

    def detect_column_types(self):
        """
        Erkennt die Datentypen der Spalten in den CSV-Daten.

        :return: Ein Dictionary, das die Spaltennamen auf ihre Datentypen abbildet.
        """
        column_types = {}
        for i, col_name in enumerate(self.header):
            col_data = [row[i] for row in self.data]
            column_types[col_name] = self._detect_type(col_data)
        return column_types

    def _detect_type(self, col_data):
        """
        Erkennt den Datentyp einer Spalte basierend auf den Daten.

        :param col_data: Eine Liste von Werten in der Spalte.
        :return: Ein String, der den Datentyp der Spalte angibt ('Numeric', 'Date', 'Text', 'Boolean', 'Currency', 'Email', 'Phone', 'Address', 'Timestamp', 'IP', 'URL', 'Hex', 'Coordinates', 'PostalCode', 'ProductCode', 'DateRange', 'UUID', 'MACAddress', 'SSN', 'CreditCard').
        """
        if all(self._is_numeric(value) for value in col_data):
            return 'Numeric'
        elif all(self._is_date(value) for value in col_data):
            return 'Date'
        elif all(self._is_boolean(value) for value in col_data):
            return 'Boolean'
        elif all(self._is_currency(value) for value in col_data):
            return 'Currency'
        elif all(self._is_email(value) for value in col_data):
            return 'Email'
        elif all(self._is_phone(value) for value in col_data):
            return 'Phone'
        elif all(self._is_address(value) for value in col_data):
            return 'Address'
        elif all(self._is_timestamp(value) for value in col_data):
            return 'Timestamp'
        elif all(self._is_ip(value) for value in col_data):
            return 'IP'
        elif all(self._is_url(value) for value in col_data):
            return 'URL'
        elif all(self._is_hex(value) for value in col_data):
            return 'Hex'
        elif all(self._is_coordinates(value) for value in col_data):
            return 'Coordinates'
        elif all(self._is_postal_code(value) for value in col_data):
            return 'PostalCode'
        elif all(self._is_product_code(value) for value in col_data):
            return 'ProductCode'
        elif all(self._is_date_range(value) for value in col_data):
            return 'DateRange'
        elif all(self._is_uuid(value) for value in col_data):
            return 'UUID'
        elif all(self._is_mac_address(value) for value in col_data):
            return 'MACAddress'
        elif all(self._is_ssn(value) for value in col_data):
            return 'SSN'
        elif all(self._is_credit_card(value) for value in col_data):
            return 'CreditCard'
        else:
            return 'Text'

    def _is_numeric(self, value):
        """
        Überprüft, ob ein Wert numerisch ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert numerisch ist, sonst False.
        """
        try:
            float(value)
            return True
        except ValueError:
            return False

    def _is_date(self, value):
        """
        Überprüft, ob ein Wert ein Datum in einem der unterstützten Formate ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein Datum ist, sonst False.
        """
        date_formats = [
            '%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%Y-%m-%d %H:%M:%S',
            '%d.%m.%Y', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M', '%d-%m-%Y',
            '%b %d, %Y', '%B %d, %Y', '%d %b %Y', '%d %B %Y'
        ]
        for date_format in date_formats:
            try:
                datetime.strptime(value, date_format)
                return True
            except ValueError:
                continue
        return False

    def _is_boolean(self, value):
        """
        Überprüft, ob ein Wert ein Boolean-Wert ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein Boolean-Wert ist, sonst False.
        """
        return value.lower() in ['true', 'false', 'yes', 'no', '1', '0']

    def _is_currency(self, value):
        """
        Überprüft, ob ein Wert ein Währungswert ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein Währungswert ist, sonst False.
        """
        currency_pattern = re.compile(r'^[€£$¥₹]\d+(\.\d{2})?$')
        return bool(currency_pattern.match(value))

    def _is_email(self, value):
        """
        Überprüft, ob ein Wert eine E-Mail-Adresse ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine E-Mail-Adresse ist, sonst False.
        """
        email_pattern = re.compile(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
        return bool(email_pattern.match(value))

    def _is_phone(self, value):
        """
        Überprüft, ob ein Wert eine Telefonnummer ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine Telefonnummer ist, sonst False.
        """
        phone_pattern = re.compile(r'^\+?\d{1,3}[-.\s]?\(?\d{1,4}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$')
        return bool(phone_pattern.match(value))

    def _is_address(self, value):
        """
        Überprüft, ob ein Wert eine Adresse ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine Adresse ist, sonst False.
        """
        address_pattern = re.compile(r'^\d+\s[a-zA-Z\s]+,\s[a-zA-Z\s]+,\s[a-zA-Z\s]+,\s\d{5}$')
        return bool(address_pattern.match(value))

    def _is_timestamp(self, value):
        """
        Überprüft, ob ein Wert ein Zeitstempel ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein Zeitstempel ist, sonst False.
        """
        timestamp_formats = [
            '%Y-%m-%d %H:%M:%S', '%d/%m/%Y %H:%M', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M'
        ]
        for timestamp_format in timestamp_formats:
            try:
                datetime.strptime(value, timestamp_format)
                return True
            except ValueError:
                continue
        return False

    def _is_ip(self, value):
        """
        Überprüft, ob ein Wert eine IP-Adresse (IPv4, IPv6 oder CIDR) ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine IP-Adresse ist, sonst False.
        """
        ipv4_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
        ipv6_pattern = re.compile(r'^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$')
        cidr_pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}$')
        return bool(ipv4_pattern.match(value)) or bool(ipv6_pattern.match(value)) or bool(cidr_pattern.match(value))

    def _is_url(self, value):
        """
        Überprüft, ob ein Wert eine URL ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine URL ist, sonst False.
        """
        url_pattern = re.compile(r'^https?://[^\s/$.?#].[^\s]*$')
        return bool(url_pattern.match(value))

    def _is_hex(self, value):
        """
        Überprüft, ob ein Wert ein hexadezimaler Wert ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein hexadezimaler Wert ist, sonst False.
        """
        hex_pattern = re.compile(r'^0x[0-9a-fA-F]+$')
        return bool(hex_pattern.match(value))

    def _is_coordinates(self, value):
        """
        Überprüft, ob ein Wert geographische Koordinaten sind.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert geographische Koordinaten sind, sonst False.
        """
        coordinates_pattern = re.compile(r'^-?\d{1,3}\.\d{1,6},\s*-?\d{1,3}\.\d{1,6}$')
        return bool(coordinates_pattern.match(value))

    def _is_postal_code(self, value):
        """
        Überprüft, ob ein Wert eine Postleitzahl ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine Postleitzahl ist, sonst False.
        """
        postal_code_pattern = re.compile(r'^\d{4,10}$')
        return bool(postal_code_pattern.match(value))

    def _is_product_code(self, value):
        """
        Überprüft, ob ein Wert ein Produktcode ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein Produktcode ist, sonst False.
        """
        product_code_pattern = re.compile(r'^[0-9A-Za-z]{12,14}$')
        return bool(product_code_pattern.match(value))

    def _is_date_range(self, value):
        """
        Überprüft, ob ein Wert ein Datum-Zeitraum ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert ein Datum-Zeitraum ist, sonst False.
        """
        date_range_pattern = re.compile(r'^\d{4}-\d{4}$')
        return bool(date_range_pattern.match(value))

    def _is_uuid(self, value):
        """
        Überprüft, ob ein Wert eine UUID ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine UUID ist, sonst False.
        """
        uuid_pattern = re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
        return bool(uuid_pattern.match(value))

    def _is_mac_address(self, value):
        """
        Überprüft, ob ein Wert eine MAC-Adresse ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine MAC-Adresse ist, sonst False.
        """
        mac_address_pattern = re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')
        return bool(mac_address_pattern.match(value))

    def _is_ssn(self, value):
        """
        Überprüft, ob ein Wert eine Sozialversicherungsnummer (SSN) ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine SSN ist, sonst False.
        """
        ssn_pattern = re.compile(r'^\d{3}-\d{2}-\d{4}$')
        return bool(ssn_pattern.match(value))

    def _is_credit_card(self, value):
        """
        Überprüft, ob ein Wert eine Kreditkartennummer ist.

        :param value: Der zu überprüfende Wert.
        :return: True, wenn der Wert eine Kreditkartennummer ist, sonst False.
        """
        credit_card_pattern = re.compile(r'^\d{16}$')
        return bool(credit_card_pattern.match(value))

# Beispielverwendung
if __name__ == "__main__":
    data = [
        ['2023-01-01 14:30:00', '123.45', 'text1', 'True', '€123.45', 'example@example.com', '+123-456-7890', '123 Main St, Springfield, IL, 62704', '192.168.0.1', 'https://www.example.com', '0x1A3F', '52.5200, 13.4050', '10115', '1234567890123', '2021-2022', '550e8400-e29b-41d4-a716-446655440000', '00:1A:2B:3C:4D:5E', '123-45-6789', '1234567812345678'],
        ['2023-01-02 15:45:00', '67.89', 'text2', 'False', '£67.89', 'test@test.com', '+987-654-3210', '456 Elm St, Shelbyville, IL, 62707', '2001:0db8:85a3:0000:0000:8a2e:0370:7334', 'http://www.test.com', '0xABCD', '48.8566, 2.3522', '60001', '9876543210987', '2022-2023', '123e4567-e89b-12d3-a456-426614174000', '11:22:33:44:55:66', '987-65-4321', '9876543212345678'],
        ['2023-01-03 16:50:00', '34.56', 'text3', 'True', '$34.56', 'user@domain.com', '+111-222-3333', '789 Oak St, Ogdenville, IL, 62708', '10.0.0.1', 'https://www.domain.com', '0x1234', '34.0522, -118.2437', '90001', '1234567890124', '2023-2024', '98765432-1234-5678-9012-345678901234', '22:33:44:55:66:77', '111-22-3333', '1111222233334444'],
        ['2023-01-04 17:15:00', '56.78', 'text4', 'False', '¥56.78', 'admin@domain.com', '+444-555-6666', '1011 Pine St, North Haverbrook, IL, 62709', '172.16.0.1', 'https://www.admin.com', '0x5678', '51.5074, -0.1278', '75001', '1234567890125', '2024-2025', '44445555-6666-7777-8888-999900001111', '33:44:55:66:77:88', '444-55-6666', '4444555566667777'],
        ['2023-01-05 18:20:00', '90.12', 'text5', 'True', '₹90.12', 'info@domain.com', '+777-888-9999', '1213 Cedar St, Brockway, IL, 62710', '192.168.1.1', 'https://www.info.com', '0x9ABC', '40.7128, -74.0060', '10001', '1234567890126', '2025-2026', '22223333-4444-5555-6666-777788889999', '44:55:66:77:88:99', '777-88-9999', '7777888899990000']
    ]
    header = ['timestamp', 'numeric', 'text', 'boolean', 'currency', 'email', 'phone', 'address', 'ip', 'url', 'hex', 'coordinates', 'postal_code', 'product_code', 'date_range', 'uuid', 'mac_address', 'ssn', 'credit_card']

    detector = CSVDataTypeDetection(data, header)
    print(detector.detect_column_types())
