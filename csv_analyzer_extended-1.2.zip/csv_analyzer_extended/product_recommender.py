#product_recommender.py
from sklearn.metrics.pairwise import cosine_similarity
from collections import defaultdict
import numpy as np
import pandas as pd
from datetime import datetime

class CSVProductRecommender:
    def __init__(self, product_data, user_data, interaction_data):
        """
        Initialisiert die ProductRecommender-Klasse.

        :param product_data: Eine Liste oder ein DataFrame mit Produktinformationen.
        :param user_data: Eine Liste oder ein DataFrame mit Benutzerdaten und Bewertungen/Präferenzen.
        :param interaction_data: Eine Liste oder ein DataFrame mit Interaktionsdaten (Klicks, Käufe, etc.).
        """
        self.product_data = product_data
        self.user_data = user_data
        self.interaction_data = interaction_data
        self.user_profiles = self._create_user_profiles()

    def recommend_based_on_similarity(self, product_id, top_n=5):
        """
        Gibt Produktempfehlungen basierend auf der Ähnlichkeit zum angegebenen Produkt zurück.

        :param product_id: Die ID des Produkts, basierend auf dem ähnliche Produkte empfohlen werden sollen.
        :param top_n: Die Anzahl der Top-Empfehlungen.
        :return: Eine Liste von empfohlenen Produkt-IDs.
        """
        product_vector = self._get_product_vector(product_id)
        similarities = cosine_similarity([product_vector], self.product_data)[0]
        similar_products = np.argsort(similarities)[::-1][:top_n + 1]
        return [self.product_data[i]['product_id'] for i in similar_products if i != product_id][:top_n]

    def recommend_for_user(self, user_id, top_n=5):
        """
        Gibt Produktempfehlungen für einen Benutzer basierend auf ähnlichen Benutzern zurück.

        :param user_id: Die ID des Benutzers, für den Empfehlungen generiert werden sollen.
        :param top_n: Die Anzahl der Top-Empfehlungen.
        :return: Eine Liste von empfohlenen Produkt-IDs.
        """
        user_vector = self._get_user_vector(user_id)
        similarities = cosine_similarity([user_vector], self.user_data)[0]
        similar_users = np.argsort(similarities)[::-1]
        recommended_products = self._get_top_products_from_similar_users(similar_users, top_n)
        return recommended_products

    def _get_product_vector(self, product_id):
        """
        Hilfsfunktion, um den Produktvektor für die Berechnung zu erhalten.
        """
        # Logik zur Extraktion des Produktvektors
        return self.product_data[product_id]['features']

    def _get_user_vector(self, user_id):
        """
        Hilfsfunktion, um den Benutzervektor für die Berechnung zu erhalten.
        """
        # Logik zur Extraktion des Benutzervektors
        return self.user_data[user_id]['features']

    def _get_top_products_from_similar_users(self, similar_users, top_n):
        """
        Hilfsfunktion, um die besten Produkte aus ähnlichen Benutzern zu extrahieren.
        """
        recommended_products = defaultdict(int)
        for user in similar_users:
            for product in self.user_data[user]['rated_products']:
                recommended_products[product] += 1
        sorted_products = sorted(recommended_products.items(), key=lambda x: x[1], reverse=True)
        return [product[0] for product in sorted_products][:top_n]

    def _create_user_profiles(self):
        """
        Erstellt Nutzerprofile basierend auf Kaufverhalten oder Interessen.
        """
        user_profiles = {}
        for user in self.user_data:
            user_id = user['user_id']
            interactions = self.interaction_data[self.interaction_data['user_id'] == user_id]
            user_profiles[user_id] = self._calculate_user_profile(interactions)
        return user_profiles

    def _calculate_user_profile(self, interactions):
        """
        Berechnet das Nutzerprofil basierend auf den Interaktionen.
        """
        profile = defaultdict(int)
        for index, interaction in interactions.iterrows():
            product_id = interaction['product_id']
            product_vector = self._get_product_vector(product_id)
            timestamp = interaction['timestamp']
            time_decay = self._time_decay(timestamp)
            for i, value in enumerate(product_vector):
                profile[i] += value * time_decay
        return list(profile.values())

    def _time_decay(self, timestamp):
        """
        Berechnet den Zeitverfallsfaktor.
        """
        current_time = datetime.now()
        time_diff = (current_time - timestamp).days
        return 0.9 ** time_diff

    def _add_implicit_feedback(self, user_id, product_id, interaction_type):
        """
        Fügt implizites Feedback (z.B. Klicks) hinzu.
        """
        timestamp = datetime.now()
        self.interaction_data = self.interaction_data.append({
            'user_id': user_id,
            'product_id': product_id,
            'interaction_type': interaction_type,
            'timestamp': timestamp
        }, ignore_index=True)
        self.user_profiles[user_id] = self._calculate_user_profile(self.interaction_data[self.interaction_data['user_id'] == user_id])

    def _consider_context(self, user_id, top_n=5):
        """
        Berücksichtigt saisonale Trends und tageszeitabhängige Präferenzen.
        """
        # Beispielhafte Implementierung für saisonale Trends und tageszeitabhängige Präferenzen
        current_time = datetime.now()
        seasonal_trends = self._get_seasonal_trends(current_time)
        time_of_day_preferences = self._get_time_of_day_preferences(current_time)

        user_vector = self._get_user_vector(user_id)
        similarities = cosine_similarity([user_vector], self.user_data)[0]
        similar_users = np.argsort(similarities)[::-1]
        recommended_products = self._get_top_products_from_similar_users(similar_users, top_n)

        # Anpassen der Empfehlungen basierend auf saisonalen Trends und tageszeitabhängigen Präferenzen
        adjusted_recommendations = []
        for product in recommended_products:
            if product in seasonal_trends and product in time_of_day_preferences:
                adjusted_recommendations.append(product)

        return adjusted_recommendations[:top_n]

    def _get_seasonal_trends(self, current_time):
        """
        Gibt saisonale Trends basierend auf der aktuellen Zeit zurück.
        """
        # Beispielhafte Implementierung für saisonale Trends
        seasonal_trends = {
            'winter': [1, 2, 3],
            'spring': [4, 5, 6],
            'summer': [7, 8, 9],
            'fall': [10, 11, 12]
        }
        season = self._get_season(current_time)
        return seasonal_trends.get(season, [])

    def _get_time_of_day_preferences(self, current_time):
        """
        Gibt tageszeitabhängige Präferenzen basierend auf der aktuellen Zeit zurück.
        """
        # Beispielhafte Implementierung für tageszeitabhängige Präferenzen
        time_of_day_preferences = {
            'morning': [1, 2, 3],
            'afternoon': [4, 5, 6],
            'evening': [7, 8, 9],
            'night': [10, 11, 12]
        }
        time_of_day = self._get_time_of_day(current_time)
        return time_of_day_preferences.get(time_of_day, [])

    def _get_season(self, current_time):
        """
        Gibt die aktuelle Jahreszeit basierend auf der aktuellen Zeit zurück.
        """
        month = current_time.month
        if month in [12, 1, 2]:
            return 'winter'
        elif month in [3, 4, 5]:
            return 'spring'
        elif month in [6, 7, 8]:
            return 'summer'
        else:
            return 'fall'

    def _get_time_of_day(self, current_time):
        """
        Gibt die aktuelle Tageszeit basierend auf der aktuellen Zeit zurück.
        """
        hour = current_time.hour
        if 6 <= hour < 12:
            return 'morning'
        elif 12 <= hour < 18:
            return 'afternoon'
        elif 18 <= hour < 22:
            return 'evening'
        else:
            return 'night'

# Beispielverwendung
if __name__ == "__main__":
    # Beispielhafte Daten für Produkte und Benutzer
    product_data = [{'product_id': 1, 'features': [1, 0, 0]}, {'product_id': 2, 'features': [0, 1, 0]}, {'product_id': 3, 'features': [0, 0, 1]}]
    user_data = [{'user_id': 1, 'features': [1, 0, 0], 'rated_products': [1, 2]}, {'user_id': 2, 'features': [0, 1, 0], 'rated_products': [2, 3]}]
    interaction_data = pd.DataFrame([
        {'user_id': 1, 'product_id': 1, 'interaction_type': 'click', 'timestamp': datetime(2023, 1, 1)},
        {'user_id': 1, 'product_id': 2, 'interaction_type': 'purchase', 'timestamp': datetime(2023, 1, 2)},
        {'user_id': 2, 'product_id': 2, 'interaction_type': 'click', 'timestamp': datetime(2023, 1, 3)},
        {'user_id': 2, 'product_id': 3, 'interaction_type': 'purchase', 'timestamp': datetime(2023, 1, 4)}
    ])

    recommender = ProductRecommender(product_data, user_data, interaction_data)

    # Empfehlungen basierend auf Ähnlichkeit zum Produkt mit ID 1
    print(recommender.recommend_based_on_similarity(product_id=1))

    # Empfehlungen für Benutzer mit ID 1
    print(recommender.recommend_for_user(user_id=1))

    # Empfehlungen für Benutzer mit ID 1 unter Berücksichtigung des Kontexts
    print(recommender._consider_context(user_id=1))
