import csv
import json
import os
import multiprocessing as mp
import sqlite3  # Für die SQLite-Integration
import openpyxl  # Für den Excel-Export
import pyarrow as pa  # Für den Parquet-Export
import pyarrow.parquet as pq  # Für den Parquet-Export
import pyarrow.feather as feather  # Für den Feather-Export
import h5py  # Für den HDF5-Export
import avro.schema  # Für den Avro-Export
import avro.io  # Für den Avro-Export
import toml  # Für den TOML-Export
import msgpack  # Für den MessagePack-Export
import pickle  # Für den Pickle-Export
import yaml  # Für den YAML-Export
import zipfile  # Für den CSV-Zip-Export
import gzip  # Für die Gzip-Kompression
import bz2  # Für die Bzip2-Kompression
import pandas as pd  # Für den Excel-Export mit mehreren Blättern
import gspread  # Für den Google Sheets-Export
import oauth2client.service_account  # Für die Google Sheets API
import pymysql  # Für den MySQL-Dump
import psycopg2  # Für den PostgreSQL-Dump
import ndjson  # Für den NDJSON-Export
import cbor2  # Für den CBOR-Export
import geojson  # Für den GeoJSON-Export
import google.auth  # Für den BigQuery-Export
import google.cloud.bigquery  # Für den BigQuery-Export
import scipy.io  # Für den MATLAB-Export
import xlsxwriter  # Für den XLSB-Export
from odf.opendocument import load  # Für den ODF-Export
from fpdf import FPDF
from google.protobuf import json_format  # Für den Protobuf-Export
from google.protobuf.descriptor import FieldDescriptor
from google.protobuf.message import Message

class CSVExporter:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def export_to_csv(self, file_path):
        with open(file_path, 'w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(self.header)
            writer.writerows(self.data)

    def export_to_json(self, file_path):
        json_data = [dict(zip(self.header, row)) for row in self.data]
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(json_data, file, indent=4)

    def export_to_excel(self, file_path):
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.append(self.header)
        for row in self.data:
            sheet.append(row)
        workbook.save(file_path)

    def export_to_html(self, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write('<table>\n')
            file.write('  <tr>' + ''.join([f'<th>{col}</th>' for col in self.header]) + '</tr>\n')
            for row in self.data:
                file.write('  <tr>' + ''.join([f'<td>{cell}</td>' for cell in row]) + '</tr>\n')
            file.write('</table>')

    def export_to_parquet(self, file_path):
        table = pa.Table.from_arrays([pa.array([row[i] for row in self.data]) for i in range(len(self.header))],
                                     names=self.header)
        pq.write_table(table, file_path)

    def export_to_markdown(self, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write('| ' + ' | '.join(self.header) + ' |\n')
            file.write('|' + '---|' * len(self.header) + '\n')
            for row in self.data:
                file.write('| ' + ' | '.join(row) + ' |\n')

    def export_to_latex(self, file_path):
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write('\\begin{tabular}{' + ' | '.join(['l'] * len(self.header)) + '}\n')
            file.write('  ' + ' & '.join(self.header) + ' \\\\\n')
            file.write('  \\hline\n')
            for row in self.data:
                file.write('  ' + ' & '.join(row) + ' \\\\\n')
            file.write('\\end{tabular}\n')

    def export_to_pdf(self, file_path):
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)

        # Kopfzeile
        pdf.set_font("Arial", 'B', 12)
        for col in self.header:
            pdf.cell(40, 10, col, 1, 0, 'C')
        pdf.ln()

        # Datenzeilen
        pdf.set_font("Arial", size=12)
        for row in self.data:
            for item in row:
                pdf.cell(40, 10, item, 1, 0, 'C')
            pdf.ln()

        pdf.output(file_path)

    def export_to_sql(self, table_name, cursor):
        """Exportiert die Daten in eine SQL-Datenbank."""
        columns = ', '.join([f'"{col}"' for col in self.header])
        placeholders = ', '.join(['?'] * len(self.header))
        insert_query = f'INSERT INTO {table_name} ({columns}) VALUES ({placeholders})'
        for row in self.data:
            cursor.execute(insert_query, row)

    def export_to_xml(self, file_path):
        """Exportiert die Daten in eine XML-Datei."""
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            file.write('<data>\n')
            for row in self.data:
                file.write('  <row>\n')
                for tag, value in zip(self.header, row):
                    file.write(f'    <{tag}>{value}</{tag}>\n')
                file.write('  </row>\n')
            file.write('</data>\n')

    def export_to_yaml(self, file_path):
        """Exportiert die Daten in eine YAML-Datei."""
        yaml_data = [dict(zip(self.header, row)) for row in self.data]
        with open(file_path, 'w', encoding='utf-8') as file:
            yaml.dump(yaml_data, file, default_flow_style=False)

    def export_to_feather(self, file_path):
        """Exportiert die Daten in eine Feather-Datei."""
        table = pa.Table.from_arrays([pa.array([row[i] for row in self.data]) for i in range(len(self.header))],
                                     names=self.header)
        feather.write_feather(table, file_path)

    def export_to_hdf5(self, file_path):
        """Exportiert die Daten in eine HDF5-Datei."""
        with h5py.File(file_path, 'w') as hdf:
            for i, col in enumerate(self.header):
                hdf.create_dataset(col, data=[row[i] for row in self.data])

    def export_to_avro(self, file_path):
            """Exportiert die Daten in eine Avro-Datei."""
            schema = avro.schema.Parse(json.dumps({
                "type": "record",
                "name": "Data",
                "fields": [{"name": col, "type": "string"} for col in self.header]
            }))
            
            with open(file_path, 'wb') as file:
                writer = avro.datafile.DataFileWriter(file, avro.io.DatumWriter(), schema)
                for row in self.data:
                    writer.append(dict(zip(self.header, row)))
                writer.close()

    def export_to_toml(self, file_path):
        """Exportiert die Daten in eine TOML-Datei."""
        toml_data = [dict(zip(self.header, row)) for row in self.data]
        with open(file_path, 'w', encoding='utf-8') as file:
            toml.dump(toml_data, file)

    def export_to_msgpack(self, file_path):
        """Exportiert die Daten in eine MessagePack-Datei."""
        msgpack_data = [dict(zip(self.header, row)) for row in self.data]
        with open(file_path, 'wb') as file:
            file.write(msgpack.packb(msgpack_data))

    def export_to_protobuf(self, file_path, proto_class):
        """Exportiert die Daten in eine Protobuf-Datei."""
        proto_data = [proto_class(**dict(zip(self.header, row))) for row in self.data]
        with open(file_path, 'wb') as file:
            for data in proto_data:
                file.write(data.SerializeToString())

    def export_to_orc(self, file_path):
        """Exportiert die Daten in eine ORC-Datei."""
        table = pa.Table.from_arrays([pa.array([row[i] for row in self.data]) for i in range(len(self.header))],
                                     names=self.header)
        orc.write_table(table, file_path)

    def export_to_pickle(self, file_path):
        """Exportiert die Daten in eine Pickle-Datei."""
        with open(file_path, 'wb') as file:
            pickle.dump(self.data, file)

    def export_to_sqlite_dump(self, file_path):
        """Exportiert die Daten als vollständigen SQLite-Dump."""
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE data (' + ', '.join([f'"{col}" TEXT' for col in self.header]) + ')')
        for row in self.data:
            cursor.execute('INSERT INTO data VALUES (' + ', '.join(['?'] * len(self.header)) + ')', row)
        conn.commit()
        with open(file_path, 'w') as file:
            for line in conn.iterdump():
                file.write(f'{line}\n')
        conn.close()

    def export_to_csv_zip(self, file_path):
        """Exportiert CSV-Daten als komprimierte .zip-Datei."""
        with zipfile.ZipFile(file_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            csv_file_path = 'data.csv'
            with open(csv_file_path, 'w', newline='', encoding='utf-8') as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow(self.header)
                writer.writerows(self.data)
            zipf.write(csv_file_path)
            os.remove(csv_file_path)

    def export_to_excel_multi_sheet(self, file_path, sheet_names):
        """Exportiert die Daten in eine Excel-Datei mit mehreren Arbeitsblättern."""
        workbook = openpyxl.Workbook()
        for i, sheet_name in enumerate(sheet_names):
            sheet = workbook.create_sheet(title=sheet_name)
            sheet.append(self.header)
            for row in self.data:
                sheet.append(row)
        workbook.save(file_path)

    def export_to_google_sheets(self, spreadsheet_id, sheet_name, credentials_file):
        """Exportiert die Daten direkt zu Google Sheets über die Google Sheets API."""
        credentials = oauth2client.service_account.ServiceAccountCredentials.from_json_keyfile_name(
            credentials_file,
            ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive']
        )
        gc = gspread.authorize(credentials)
        spreadsheet = gc.open_by_key(spreadsheet_id)
        worksheet = spreadsheet.worksheet(sheet_name)
        worksheet.update([self.header] + self.data)

    def export_to_csv_gzip(self, file_path):
        """Exportiert CSV-Daten in komprimierter Form (.csv.gz)."""
        with gzip.open(file_path, 'wt', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(self.header)
            writer.writerows(self.data)

    def export_to_csv_bzip2(self, file_path):
        """Exportiert CSV-Daten in komprimierter Form (.csv.bz2)."""
        with bz2.open(file_path, 'wt', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(self.header)
            writer.writerows(self.data)

    def export_to_delta_lake(self, file_path):
        """Exportiert die Daten im Delta Lake Format."""
        # Delta Lake-Export erfordert eine spezielle Integration, die hier nicht vollständig implementiert werden kann.
        pass

    def export_to_arrow_ipc(self, file_path):
        """Exportiert die Daten im Arrow-IPC-Stream-Format."""
        table = pa.Table.from_arrays([pa.array([row[i] for row in self.data]) for i in range(len(self.header))],
                                     names=self.header)
        with pa.OSFile(file_path, 'wb') as sink:
            with pa.ipc.new_file(sink, table.schema) as writer:
                writer.write_table(table)

    def export_to_mysql_dump(self, file_path, db_config):
        """Exportiert die Daten als MySQL-Dump."""
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute('CREATE DATABASE IF NOT EXISTS temp_db')
        cursor.execute('USE temp_db')
        cursor.execute('CREATE TABLE data (' + ', '.join([f'"{col}" TEXT' for col in self.header]) + ')')
        for row in self.data:
            cursor.execute('INSERT INTO data VALUES (' + ', '.join(['%s'] * len(self.header)) + ')', row)
        conn.commit()
        with open(file_path, 'w') as file:
            for line in conn.iterdump():
                file.write(f'{line}\n')
        conn.close()

    def export_to_postgresql_dump(self, file_path, db_config):
        """Exportiert die Daten als PostgreSQL-Dump."""
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE data (' + ', '.join([f'"{col}" TEXT' for col in self.header]) + ')')
        for row in self.data:
            cursor.execute('INSERT INTO data VALUES (' + ', '.join(['%s'] * len(self.header)) + ')', row)
        conn.commit()
        with open(file_path, 'w') as file:
            for line in conn.iterdump():
                file.write(f'{line}\n')
        conn.close()

    

    def export_to_ndjson(self, file_path):
        """Exportiert die Daten in eine NDJSON-Datei."""
        with open(file_path, 'w', encoding='utf-8') as file:
            for row in self.data:
                file.write(json.dumps(dict(zip(self.header, row))) + '\n')

    def export_to_cbor(self, file_path):
        """Exportiert die Daten in eine CBOR-Datei."""
        cbor_data = [dict(zip(self.header, row)) for row in self.data]
        with open(file_path, 'wb') as file:
            file.write(cbor2.dumps(cbor_data))

    def export_to_geojson(self, file_path):
        """Exportiert die Daten in eine GeoJSON-Datei."""
        geojson_data = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [float(row[i]) for i in range(2)]  # Annahme: Längen- und Breitengrad sind die ersten beiden Spalten
                    },
                    "properties": dict(zip(self.header[2:], row[2:]))
                } for row in self.data
            ]
        }
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(geojson_data, file, indent=4)

    def export_to_bigquery(self, project_id, dataset_id, table_id, credentials_file):
        """Exportiert die Daten direkt zu Google BigQuery-Datasets."""
        credentials, project = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
        client = google.cloud.bigquery.Client(credentials=credentials, project=project_id)
        dataset_ref = client.dataset(dataset_id)
        table_ref = dataset_ref.table(table_id)
        table = client.get_table(table_ref)
        rows_to_insert = [dict(zip(self.header, row)) for row in self.data]
        errors = client.insert_rows_json(table, rows_to_insert)
        if errors:
            print("Encountered errors while inserting rows: {}".format(errors))

    def export_to_matlab(self, file_path):
        """Exportiert die Daten in eine MATLAB-Datei (.mat)."""
        matlab_data = {col: [row[i] for row in self.data] for i, col in enumerate(self.header)}
        scipy.io.savemat(file_path, matlab_data)
    

    def export_to_xlsb(self, file_path):
        """Exportiert die Daten in eine XLSB-Datei (Excel Binary)."""
        workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
        sheet = workbook.add_worksheet()
        for col_num, col_name in enumerate(self.header):
            sheet.write(0, col_num, col_name)
        for row_num, row in enumerate(self.data):
            for col_num, cell in enumerate(row):
                sheet.write(row_num + 1, col_num, cell)
        workbook.close()



    def export_to_odf(self, file_path):
        """Exportiert die Daten in eine ODF-Datei (Open Document Format)."""
        doc = load(file_path)
        table = doc.spreadsheet.getElementsByType(Table)
        for col_num, col_name in enumerate(self.header):
            table.getCellByPosition(col_num, 0).setStringValue(col_name)
        for row_num, row in enumerate(self.data):
            for col_num, cell in enumerate(row):
                table.getCellByPosition(col_num, row_num + 1).setStringValue(cell)
        doc.save(file_path)

# Beispielverwendung
if __name__ == "__main__":
    # Beispielhafte Daten
    data = [
        ['Alice', 25, 'Engineer'],
        ['Bob', 30, 'Designer'],
        ['Charlie', 35, 'Manager']
    ]
    header = ['Name', 'Age', 'Occupation']

    exporter = CSVExporter(data, header)

    # Exportieren in verschiedene Formate
    exporter.export_to_csv('output.csv')
    exporter.export_to_json('output.json')
    exporter.export_to_excel('output.xlsx')
    exporter.export_to_html('output.html')
    exporter.export_to_parquet('output.parquet')
    exporter.export_to_markdown('output.md')
    exporter.export_to_latex('output.tex')
    exporter.export_to_pdf('output.pdf')

    # Exportieren in eine SQLite-Datenbank
    conn = sqlite3.connect('output.db')
    cursor = conn.cursor()
    cursor.execute('CREATE TABLE IF NOT EXISTS people (Name TEXT, Age INTEGER, Occupation TEXT)')
    exporter.export_to_sql('people', cursor)
    conn.commit()
    conn.close()

    # Exportieren in eine XML-Datei
    exporter.export_to_xml('output.xml')

    # Exportieren in eine YAML-Datei
    exporter.export_to_yaml('output.yaml')

    # Exportieren in eine Feather-Datei
    exporter.export_to_feather('output.feather')

    # Exportieren in eine HDF5-Datei
    exporter.export_to_hdf5('output.hdf5')

    # Exportieren in eine Avro-Datei
    exporter.export_to_avro('output.avro')

    # Exportieren in eine TOML-Datei
    exporter.export_to_toml('output.toml')

    # Exportieren in eine MessagePack-Datei
    exporter.export_to_msgpack('output.msgpack')

    # Exportieren in eine ORC-Datei
    exporter.export_to_orc('output.orc')

    # Exportieren in eine Pickle-Datei
    exporter.export_to_pickle('output.pickle')

    # Exportieren als vollständigen SQLite-Dump
    exporter.export_to_sqlite_dump('output.sqlite.dump')

    # Exportieren in eine komprimierte CSV-Zip-Datei
    exporter.export_to_csv_zip('output.csv.zip')

    # Exportieren in eine Excel-Datei mit mehreren Arbeitsblättern
    exporter.export_to_excel_multi_sheet('output_multi_sheet.xlsx', ['Sheet1', 'Sheet2'])

    # Exportieren direkt zu Google Sheets
    exporter.export_to_google_sheets('your_spreadsheet_id', 'Sheet1', 'path_to_credentials.json')

    # Exportieren in eine komprimierte CSV-Gzip-Datei
    exporter.export_to_csv_gzip('output.csv.gz')

    # Exportieren in eine komprimierte CSV-Bzip2-Datei
    exporter.export_to_csv_bzip2('output.csv.bz2')

    # Exportieren im Delta Lake Format (nicht vollständig implementiert)
    exporter.export_to_delta_lake('output.delta')

    # Exportieren im Arrow-IPC-Stream-Format
    exporter.export_to_arrow_ipc('output.ipc')

    # Exportieren als MySQL-Dump
    exporter.export_to_mysql_dump('output.mysql.dump', {
        'host': 'localhost',
        'user': 'root',
        'password': 'password',
        'database': 'test_db'
    })

    # Exportieren als PostgreSQL-Dump
    exporter.export_to_postgresql_dump('output.postgresql.dump', {
        'host': 'localhost',
        'user': 'postgres',
        'password': 'password',
        'database': 'test_db'
    })

    # Exportieren als MSSQL-Dump
    exporter.export_to_mssql_dump('output.mssql.dump', {
        'DRIVER': '{ODBC Driver 17 for SQL Server}',
        'SERVER': 'localhost',
        'DATABASE': 'test_db',
        'UID': 'sa',
        'PWD': 'password'
    })

    # Exportieren in eine NDJSON-Datei
    exporter.export_to_ndjson('output.ndjson')

    # Exportieren in eine CBOR-Datei
    exporter.export_to_cbor('output.cbor')

    # Exportieren in eine GeoJSON-Datei
    exporter.export_to_geojson('output.geojson')

    # Exportieren direkt zu Google BigQuery
    exporter.export_to_bigquery('your_project_id', 'your_dataset_id', 'your_table_id', 'path_to_credentials.json')

    # Exportieren in eine MATLAB-Datei
    exporter.export_to_matlab('output.mat')

    # Exportieren in eine SPSS-Datei
    exporter.export_to_spss('output.sav')

    # Exportieren in eine SAS-Datei
    exporter.export_to_sas('output.sas7bdat')

    # Exportieren als R-Datenframe-Datei
    exporter.export_to_r_dataframe('output.rds')

    # Exportieren in eine Stata-Datei
    exporter.export_to_stata('output.dta')

    # Exportieren in eine XLSB-Datei
    exporter.export_to_xlsb('output.xlsb')

    # Exportieren direkt zu Apache Kafka
    exporter.export_to_apache_kafka('your_topic', 'localhost:9092')

    # Exportieren in eine ODF-Datei
    exporter.export_to_odf('output.ods')
