from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LinearRegression

def cross_validate_regression(self, target_col, *feature_cols, cv=5):
    y_index = self.header.index(target_col)
    X_indices = [self.header.index(col) for col in feature_cols]
    X = [[float(row[i]) for i in X_indices] for row in self.data]
    y = [float(row[y_index]) for row in self.data]
    model = LinearRegression()
    scores = cross_val_score(model, X, y, cv=cv)
    return scores.mean()
