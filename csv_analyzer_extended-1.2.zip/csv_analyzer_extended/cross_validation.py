# cross_validation.py
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet, BayesianRidge, HuberRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import make_scorer, mean_squared_error, mean_absolute_error, r2_score, mean_squared_log_error, explained_variance_score
from typing import List, Union, Callable

class CSVCrossValidation:
    def __init__(self, data: List[List[str]], header: List[str]):
        self.data = data
        self.header = header

    def cross_validate_regression(self, target_col: str, *feature_cols: str, cv: int = 5, model=None, scoring: Union[str, Callable] = 'neg_mean_squared_error') -> float:
        """
        Führt Kreuzvalidierung für ein Regressionsmodell durch.

        Args:
            target_col (str): Der Name der Zielspalte.
            *feature_cols (str): Die Namen der Merkmalsspalten.
            cv (int): Die Anzahl der Kreuzvalidierungsfalten.
            model: Das Regressionsmodell, das verwendet werden soll. Standardmäßig wird LinearRegression verwendet.
            scoring (Union[str, Callable]): Die Bewertungsmetrik, die verwendet werden soll. Standardmäßig wird 'neg_mean_squared_error' verwendet.

        Returns:
            float: Der durchschnittliche Kreuzvalidierungsscore.
        """
        try:
            y_index = self.header.index(target_col)
            X_indices = [self.header.index(col) for col in feature_cols]
        except ValueError as e:
            raise ValueError(f"Spaltennamen nicht gefunden: {e}")

        X = [[float(row[i]) for i in X_indices] for row in self.data]
        y = [float(row[y_index]) for row in self.data]

        if model is None:
            model = LinearRegression()  # Standardmodell LinearRegression

        scores = cross_val_score(model, X, y, cv=cv, scoring=scoring)
        return scores.mean()

# Beispielverwendung
if __name__ == "__main__":
    # Beispiel-Daten und Header
    data = [
        ["1.0", "2.0", "3.0"],
        ["4.0", "5.0", "6.0"],
        ["7.0", "8.0", "9.0"]
    ]
    header = ["Spalte1", "Spalte2", "Spalte3"]

    # Erstellen eines CSVCrossValidation-Objekts
    cross_validation = CSVCrossValidation(data, header)

    # Kreuzvalidierung mit LinearRegression (Standard)
    mean_score_lr = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2")
    print("LinearRegression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_lr)

    # Kreuzvalidierung mit DecisionTreeRegressor
    mean_score_dt = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=DecisionTreeRegressor())
    print("DecisionTreeRegressor Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_dt)

    # Kreuzvalidierung mit RandomForestRegressor
    mean_score_rf = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=RandomForestRegressor())
    print("RandomForestRegressor Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_rf)

    # Kreuzvalidierung mit Ridge Regression
    mean_score_ridge = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=Ridge())
    print("Ridge Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_ridge)

    # Kreuzvalidierung mit Lasso Regression
    mean_score_lasso = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=Lasso())
    print("Lasso Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_lasso)

    # Kreuzvalidierung mit ElasticNet
    mean_score_elasticnet = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=ElasticNet())
    print("ElasticNet Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_elasticnet)

    # Kreuzvalidierung mit Polynomial Regression
    poly = PolynomialFeatures(degree=2)
    X_poly = poly.fit_transform([[float(row[i]) for i in [0, 1]] for row in data])
    mean_score_poly = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=LinearRegression().fit(X_poly, y))
    print("Polynomial Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_poly)

    # Kreuzvalidierung mit Gradient Boosting Regression
    mean_score_gb = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=GradientBoostingRegressor())
    print("Gradient Boosting Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_gb)

    # Kreuzvalidierung mit Support Vector Regression
    mean_score_svr = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=SVR())
    print("Support Vector Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_svr)

    # Kreuzvalidierung mit K-Nearest Neighbors Regression
    mean_score_knn = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=KNeighborsRegressor())
    print("K-Nearest Neighbors Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_knn)

    # Kreuzvalidierung mit Bayesian Ridge Regression
    mean_score_bayesian = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=BayesianRidge())
    print("Bayesian Ridge Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_bayesian)

    # Kreuzvalidierung mit Huber Regression
    mean_score_huber = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", model=HuberRegressor())
    print("Huber Regression Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_error):", mean_score_huber)

    # Kreuzvalidierung mit Mean Absolute Error (MAE)
    mean_score_mae = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", scoring='neg_mean_absolute_error')
    print("Durchschnittlicher Kreuzvalidierungsscore (neg_mean_absolute_error):", mean_score_mae)

    # Kreuzvalidierung mit R² Score (Bestimmtheitsmaß)
    mean_score_r2 = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", scoring='r2')
    print("Durchschnittlicher Kreuzvalidierungsscore (r2):", mean_score_r2)

    # Kreuzvalidierung mit Mean Squared Logarithmic Error (MSLE)
    mean_score_msle = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", scoring='neg_mean_squared_log_error')
    print("Durchschnittlicher Kreuzvalidierungsscore (neg_mean_squared_log_error):", mean_score_msle)

    # Kreuzvalidierung mit Explained Variance Score
    mean_score_evs = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", scoring='explained_variance')
    print("Durchschnittlicher Kreuzvalidierungsscore (explained_variance):", mean_score_evs)

    # Kreuzvalidierung mit einer benutzerdefinierten Metrik
    custom_scorer = make_scorer(mean_squared_error, greater_is_better=False)
    mean_score_custom = cross_validation.cross_validate_regression("Spalte3", "Spalte1", "Spalte2", scoring=custom_scorer)
    print("Durchschnittlicher Kreuzvalidierungsscore (benutzerdefinierte Metrik):", mean_score_custom)
