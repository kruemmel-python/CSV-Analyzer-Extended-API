import matplotlib.pyplot as plt

class CSVVisualizer:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def plot_histogram(self, column_name, bins=10):
        index = self.header.index(column_name)
        column_data = [float(row[index]) for row in self.data]
        plt.hist(column_data, bins=bins)
        plt.title(f'Histogram of {column_name}')
        plt.show()

    def plot_scatter(self, col1, col2):
        index1 = self.header.index(col1)
        index2 = self.header.index(col2)
        data1 = [float(row[index1]) for row in self.data]
        data2 = [float(row[index2]) for row in self.data]
        plt.scatter(data1, data2)
        plt.title(f'Scatter Plot of {col1} vs {col2}')
        plt.xlabel(col1)
        plt.ylabel(col2)
        plt.show()
