# visualizer.py
import matplotlib
matplotlib.use('TkAgg')  # Setzt das Backend auf TkAgg
import matplotlib.pyplot as plt

class CSVVisualizer:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def plot_histogram(self, column_name, bins=10, title=None, xlabel=None, ylabel=None, color='blue'):
        index = self.header.index(column_name)
        column_data = [float(row[index]) for row in self.data]
        plt.hist(column_data, bins=bins, color=color)
        
        # Setzen von Titel und Achsenbeschriftungen, falls angegeben
        plt.title(title if title else f'Histogram of {column_name}')
        plt.xlabel(xlabel if xlabel else column_name)
        plt.ylabel(ylabel if ylabel else 'Frequency')
        
        plt.show()

    def plot_scatter(self, col1, col2, title=None, xlabel=None, ylabel=None, color='blue'):
        index1 = self.header.index(col1)
        index2 = self.header.index(col2)
        data1 = [float(row[index1]) for row in self.data]
        data2 = [float(row[index2]) for row in self.data]
        plt.scatter(data1, data2, color=color)
        
        # Setzen von Titel und Achsenbeschriftungen, falls angegeben
        plt.title(title if title else f'Scatter Plot of {col1} vs {col2}')
        plt.xlabel(xlabel if xlabel else col1)
        plt.ylabel(ylabel if ylabel else col2)
        
        plt.show()
