class CSVProfiling:
    def __init__(self, data, header):
        self.data = data
        self.header = header

    def data_profiling(self):
        profile = {}
        for col_name in self.header:
            col_data = [float(row[self.header.index(col_name)]) for row in self.data if row[self.header.index(col_name)] != '']
            profile[col_name] = {
                'mean': sum(col_data) / len(col_data),
                'std_dev': (sum((x - sum(col_data) / len(col_data)) ** 2 for x in col_data) / len(col_data)) ** 0.5,
                'missing': len(self.data) - len(col_data),
                'min': min(col_data),
                'max': max(col_data)
            }
        return profile
