import math
from collections import Counter
from statistics import mode

class CSVProfiling:
    def __init__(self, data, header):
        self.data = data
        self.header = header
        self._validate_data()

    def _validate_data(self):
        if not isinstance(self.data, list) or not all(isinstance(row, list) for row in self.data):
            raise ValueError("Data must be a list of lists.")
        if not isinstance(self.header, list) or not all(isinstance(col, str) for col in self.header):
            raise ValueError("Header must be a list of strings.")
        if len(self.header) != len(self.data[0]):
            raise ValueError("Header and data rows must have the same length.")

    def data_profiling(self):
        profile = {}
        for col_name in self.header:
            col_index = self.header.index(col_name)
            col_data = [row[col_index] for row in self.data if row[col_index] != '']

            if self._is_numeric_column(col_data):
                profile[col_name] = self._profile_numeric_column(col_data)
            else:
                profile[col_name] = self._profile_categorical_column(col_data)

        return profile

    def _is_numeric_column(self, col_data):
        try:
            [float(x) for x in col_data]
            return True
        except ValueError:
            return False

    def _profile_numeric_column(self, col_data):
        col_data = [float(x) for x in col_data]
        mean = sum(col_data) / len(col_data)
        std_dev = (sum((x - mean) ** 2 for x in col_data) / len(col_data)) ** 0.5
        missing = len(self.data) - len(col_data)
        min_val = min(col_data)
        max_val = max(col_data)
        median = self._calculate_median(col_data)
        count = len(col_data)
        quartiles = self._calculate_quartiles(col_data)
        mode_val = self._calculate_mode(col_data)
        skewness = self._calculate_skewness(col_data, mean, std_dev)
        kurtosis = self._calculate_kurtosis(col_data, mean, std_dev)
        range_val = max_val - min_val
        iqr = quartiles[2] - quartiles[0]

        return {
            'mean': mean,
            'std_dev': std_dev,
            'missing': missing,
            'min': min_val,
            'max': max_val,
            'median': median,
            'count': count,
            'quartiles': quartiles,
            'mode': mode_val,
            'skewness': skewness,
            'kurtosis': kurtosis,
            'range': range_val,
            'iqr': iqr
        }

    def _profile_categorical_column(self, col_data):
        unique_values = len(set(col_data))
        most_common = Counter(col_data).most_common(1)
        missing = len(self.data) - len(col_data)

        return {
            'unique_values': unique_values,
            'most_common': most_common,
            'missing': missing
        }

    def _extract_numeric_column(self, col_index):
        """
        Extrahiert numerische Daten aus einer bestimmten Spalte, ignoriert nicht-numerische Werte.
        """
        col_data = []
        for row in self.data:
            try:
                if row[col_index] != '':
                    col_data.append(float(row[col_index]))
            except ValueError:
                # Ignoriere nicht-numerische Werte
                continue
        return col_data

    def _calculate_median(self, data):
        sorted_data = sorted(data)
        n = len(sorted_data)
        if n % 2 == 0:
            return (sorted_data[n // 2 - 1] + sorted_data[n // 2]) / 2
        else:
            return sorted_data[n // 2]

    def _calculate_quartiles(self, data):
        sorted_data = sorted(data)
        n = len(sorted_data)
        q1 = self._percentile(sorted_data, 0.25)
        q2 = self._percentile(sorted_data, 0.5)
        q3 = self._percentile(sorted_data, 0.75)
        return (q1, q2, q3)

    def _percentile(self, data, percentile):
        sorted_data = sorted(data)
        k = (len(sorted_data) - 1) * percentile
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return sorted_data[int(k)]
        d0 = sorted_data[int(f)] * (c - k)
        d1 = sorted_data[int(c)] * (k - f)
        return d0 + d1

    def _calculate_mode(self, data):
        try:
            return mode(data)
        except:
            return None

    def _calculate_skewness(self, data, mean, std_dev):
        n = len(data)
        skewness = (sum((x - mean) ** 3 for x in data) * n) / ((n - 1) * (n - 2) * (std_dev ** 3))
        return skewness

    def _calculate_kurtosis(self, data, mean, std_dev):
        n = len(data)
        kurtosis = (sum((x - mean) ** 4 for x in data) * n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3) * (std_dev ** 4)) - 3 * ((n - 1) ** 2) / ((n - 2) * (n - 3))
        return kurtosis

# Beispielverwendung
if __name__ == "__main__":
    # Beispielhafte Daten mit einer numerischen und nicht-numerischen Spalte
    data = [
        ['Alice', '25', 'Engineer'],
        ['Bob', '30', 'Designer'],
        ['Charlie', '35', 'Manager'],
        ['David', '', 'Analyst'],
        ['Eve', '40', '']
    ]
    header = ['Name', 'Age', 'Occupation']

    profiler = CSVProfiling(data, header)
    profile = profiler.data_profiling()
    print("Profiling:", profile)

