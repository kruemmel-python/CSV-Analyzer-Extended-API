# clustering.py
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN, MeanShift, SpectralClustering, AffinityPropagation, OPTICS, Birch
from sklearn.mixture import GaussianMixture
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.covariance import EllipticEnvelope
from scipy.cluster.hierarchy import fcluster, linkage
from typing import List, Tuple, Union

class CSVClustering:
    def __init__(self, data: List[List[str]], header: List[str]):
        self.data = data
        self.header = header

    def cluster_data(self, algorithm: str, n_clusters: int = None, *column_names: str) -> Union[List[int], List[str]]:
        """
        Clustert die Daten basierend auf den angegebenen Spaltennamen und dem gewählten Algorithmus.

        Args:
            algorithm (str): Der Name des Clustering-Algorithmus ('kmeans', 'agglomerative', 'dbscan', 'gmm', 'mean_shift', 'spectral', 'affinity_propagation', 'hierarchical', 'isolation_forest', 'lof', 'one_class_svm', 'elliptic_envelope', 'hbos', 'optics', 'birch', 'loda').
            n_clusters (int): Die Anzahl der Cluster (nur für 'kmeans', 'agglomerative', 'gmm', 'spectral', 'birch').
            *column_names (str): Die Namen der Spalten, die für das Clustering verwendet werden sollen.

        Returns:
            Union[List[int], List[str]]: Die Cluster-Labels für jede Zeile der Daten.
        """
        indices = [self.header.index(col) for col in column_names]
        data = [[float(row[i]) for i in indices] for row in self.data]

        # Fehlerbehandlung für leere Daten
        if not data:
            raise ValueError("Die Daten sind leer oder die angegebenen Spaltennamen sind nicht vorhanden.")

        if algorithm == 'kmeans':
            if n_clusters is None:
                raise ValueError("n_clusters muss für KMeans angegeben werden.")
            kmeans = KMeans(n_clusters=n_clusters)
            kmeans.fit(data)
            return kmeans.labels_.tolist()

        elif algorithm == 'agglomerative':
            if n_clusters is None:
                raise ValueError("n_clusters muss für Agglomerative Clustering angegeben werden.")
            agg_clustering = AgglomerativeClustering(n_clusters=n_clusters)
            agg_clustering.fit(data)
            return agg_clustering.labels_.tolist()

        elif algorithm == 'dbscan':
            dbscan = DBSCAN()
            dbscan.fit(data)
            return dbscan.labels_.tolist()

        elif algorithm == 'gmm':
            if n_clusters is None:
                raise ValueError("n_clusters muss für Gaussian Mixture Models angegeben werden.")
            gmm = GaussianMixture(n_components=n_clusters)
            gmm.fit(data)
            return gmm.predict(data).tolist()

        elif algorithm == 'mean_shift':
            mean_shift = MeanShift()
            mean_shift.fit(data)
            return mean_shift.labels_.tolist()

        elif algorithm == 'spectral':
            if n_clusters is None:
                raise ValueError("n_clusters muss für Spectral Clustering angegeben werden.")
            spectral = SpectralClustering(n_clusters=n_clusters)
            spectral.fit(data)
            return spectral.labels_.tolist()

        elif algorithm == 'affinity_propagation':
            aff_prop = AffinityPropagation()
            aff_prop.fit(data)
            return aff_prop.labels_.tolist()

        elif algorithm == 'hierarchical':
            if n_clusters is None:
                raise ValueError("n_clusters muss für Hierarchical Clustering angegeben werden.")
            Z = linkage(data, 'complete')  # Für vollständige Verknüpfung
            labels = fcluster(Z, t=n_clusters, criterion='maxclust')
            return labels.tolist()

        elif algorithm == 'isolation_forest':
            iso_forest = IsolationForest()
            iso_forest.fit(data)
            return iso_forest.predict(data).tolist()

        elif algorithm == 'lof':
            lof = LocalOutlierFactor()
            labels = lof.fit_predict(data)
            return labels.tolist()

        elif algorithm == 'one_class_svm':
            one_class_svm = OneClassSVM()
            one_class_svm.fit(data)
            labels = one_class_svm.predict(data)
            return labels.tolist()

        elif algorithm == 'elliptic_envelope':
            elliptic_envelope = EllipticEnvelope()
            elliptic_envelope.fit(data)
            labels = elliptic_envelope.predict(data)
            return labels.tolist()
        
        elif algorithm == 'birch':
            if n_clusters is None:
                raise ValueError("n_clusters muss für BIRCH angegeben werden.")
            birch = Birch(n_clusters=n_clusters)
            birch.fit(data)
            return birch.labels_.tolist()
            
        elif algorithm == 'lof':
            lof = LocalOutlierFactor(n_neighbors=min(len(data)-1, 20))  # Setzt n_neighbors auf (n_samples-1) oder weniger
            labels = lof.fit_predict(data)
            return labels.tolist()    
        
        else:
            raise ValueError("Ungültiger Algorithmus. Unterstützte Algorithmen sind: 'kmeans', 'agglomerative', 'dbscan', 'gmm', 'mean_shift', 'spectral', 'affinity_propagation', 'hierarchical', 'isolation_forest', 'lof', 'one_class_svm', 'elliptic_envelope', 'hbos', 'optics', 'birch', 'loda'.")

# Beispielverwendung
if __name__ == "__main__":
    # Beispiel-Daten und Header
    data = [
        ["1.0", "2.0", "3.0"],
        ["4.0", "5.0", "6.0"],
        ["7.0", "8.0", "9.0"]
    ]
    header = ["Spalte1", "Spalte2", "Spalte3"]

    # Erstellen eines CSVClustering-Objekts
    clustering = CSVClustering(data, header)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit KMeans
    labels_kmeans = clustering.cluster_data('kmeans', 2, "Spalte1", "Spalte2")
    print("KMeans Labels:", labels_kmeans)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Agglomerative Clustering
    labels_agglomerative = clustering.cluster_data('agglomerative', 2, "Spalte1", "Spalte2")
    print("Agglomerative Clustering Labels:", labels_agglomerative)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit DBSCAN
    labels_dbscan = clustering.cluster_data('dbscan', None, "Spalte1", "Spalte2")
    print("DBSCAN Labels:", labels_dbscan)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Gaussian Mixture Models
    labels_gmm = clustering.cluster_data('gmm', 2, "Spalte1", "Spalte2")
    print("GMM Labels:", labels_gmm)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Mean-Shift
    labels_mean_shift = clustering.cluster_data('mean_shift', None, "Spalte1", "Spalte2")
    print("Mean-Shift Labels:", labels_mean_shift)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Spectral Clustering
    labels_spectral = clustering.cluster_data('spectral', 2, "Spalte1", "Spalte2")
    print("Spectral Clustering Labels:", labels_spectral)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Affinity Propagation
    labels_affinity_propagation = clustering.cluster_data('affinity_propagation', None, "Spalte1", "Spalte2")
    print("Affinity Propagation Labels:", labels_affinity_propagation)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Hierarchical Clustering
    labels_hierarchical = clustering.cluster_data('hierarchical', 2, "Spalte1", "Spalte2")
    print("Hierarchical Clustering Labels:", labels_hierarchical)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Isolation Forest
    labels_isolation_forest = clustering.cluster_data('isolation_forest', None, "Spalte1", "Spalte2")
    print("Isolation Forest Labels:", labels_isolation_forest)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit LOF
    labels_lof = clustering.cluster_data('lof', None, "Spalte1", "Spalte2")
    print("LOF Labels:", labels_lof)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit One-Class SVM
    labels_one_class_svm = clustering.cluster_data('one_class_svm', None, "Spalte1", "Spalte2")
    print("One-Class SVM Labels:", labels_one_class_svm)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit Elliptic Envelope
    labels_elliptic_envelope = clustering.cluster_data('elliptic_envelope', None, "Spalte1", "Spalte2")
    print("Elliptic Envelope Labels:", labels_elliptic_envelope)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit HBOS
    labels_hbos = clustering.cluster_data('hbos', None, "Spalte1", "Spalte2")
    print("HBOS Labels:", labels_hbos)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit OPTICS
    labels_optics = clustering.cluster_data('optics', None, "Spalte1", "Spalte2")
    print("OPTICS Labels:", labels_optics)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit BIRCH
    labels_birch = clustering.cluster_data('birch', 2, "Spalte1", "Spalte2")
    print("BIRCH Labels:", labels_birch)

    # Clustern der Daten basierend auf den Spalten "Spalte1" und "Spalte2" mit LODA
    labels_loda = clustering.cluster_data('loda', None, "Spalte1", "Spalte2")
    print("LODA Labels:", labels_loda)
