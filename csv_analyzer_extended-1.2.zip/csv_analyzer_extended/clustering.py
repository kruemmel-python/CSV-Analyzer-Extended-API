from sklearn.cluster import KMeans

def cluster_data(self, n_clusters, *column_names):
    indices = [self.header.index(col) for col in column_names]
    data = [[float(row[i]) for i in indices] for row in self.data]
    kmeans = KMeans(n_clusters=n_clusters)
    kmeans.fit(data)
    return kmeans.labels_
